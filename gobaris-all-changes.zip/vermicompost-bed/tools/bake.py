"""Bake a soft drop shadow into each rendered layer and save the WebP files the page uses.

Usage:  python3 bake.py RENDER_DIR      (RENDER_DIR holds the PNGs written by layers.py)
Also writes ../img/extents.json: the visible top/bottom of each layer before the shadow,
relative to the disc centre, so embed_bed.py can space the layers without overlap.
"""
import json, os, sys
import numpy as np
from PIL import Image, ImageFilter

SRC = sys.argv[1]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'img')
DISC_CY = 162
LAYERS = ['jute', 'water', 'worms', 'dung', 'straw', 'bedding', 'drainage']
extents = {}
for n in LAYERS + ['bed', 'bed_empty']:
    im = Image.open(os.path.join(SRC, n + '.png')).convert('RGBA')
    a = np.asarray(im)[..., 3]
    ys = np.where((a > 30).any(1))[0]
    if n in LAYERS:
        extents[n] = [int(ys.min()) - DISC_CY, int(ys.max()) - DISC_CY]
    dy, blur, dark = (14, 12, 0.5) if n in LAYERS else (20, 18, 0.6)
    sh = Image.new('L', im.size, 0)
    sh.paste(im.getchannel('A'), (0, dy))
    sh = sh.filter(ImageFilter.GaussianBlur(blur)).point(lambda v: int(v * dark))
    base = Image.new('RGBA', im.size, (0, 0, 0, 0))
    base.putalpha(sh)
    out = Image.alpha_composite(base, im)
    out.save(os.path.join(OUT, n + '.webp'), 'WEBP', quality=86, method=4)
json.dump(extents, open(os.path.join(OUT, 'extents.json'), 'w'), indent=1)
print(extents)
