"""Small procedural-texture toolkit (numpy + PIL) for realistic material renders."""
import numpy as np
from PIL import Image, ImageFilter

RNG = np.random.default_rng(11)


def rng(seed):
    return np.random.default_rng(seed)


def value_noise(h, w, cell, seed=0):
    """Smooth value noise: random grid upsampled bicubically."""
    r = rng(seed)
    gh, gw = max(2, int(h / cell) + 3), max(2, int(w / cell) + 3)
    g = r.random((gh, gw)).astype(np.float32)
    im = Image.fromarray((g * 255).astype(np.uint8), 'L').resize(
        (int(gw * cell), int(gh * cell)), Image.BICUBIC)
    a = np.asarray(im, dtype=np.float32)[:h, :w] / 255.0
    return a


def fbm(h, w, base=64, octaves=5, seed=0, gain=0.5):
    out = np.zeros((h, w), np.float32)
    amp, tot, cell = 1.0, 0.0, base
    for o in range(octaves):
        out += amp * value_noise(h, w, max(1, cell), seed + o * 17)
        tot += amp
        amp *= gain
        cell /= 2
    return out / tot


def _box1d(a, r, axis):
    if r < 1:
        return a
    pad = [(0, 0)] * a.ndim
    pad[axis] = (r + 1, r)
    p = np.pad(a, pad, mode='edge')
    c = np.cumsum(p, axis=axis, dtype=np.float64)
    n = a.shape[axis]
    hi = np.take(c, np.arange(2 * r + 1, 2 * r + 1 + n), axis=axis)
    lo = np.take(c, np.arange(0, n), axis=axis)
    return ((hi - lo) / (2 * r + 1)).astype(np.float32)


def blur(a, r):
    """Approximate gaussian blur (three box passes) on a float array."""
    if r <= 0:
        return a
    k = max(1, int(round(r * 0.9)))
    out = a.astype(np.float32)
    for _ in range(3):
        out = _box1d(out, k, 0)
        out = _box1d(out, k, 1)
    return out


def blur_rgb(a, r):
    return np.stack([blur(a[..., i], r) for i in range(a.shape[-1])], -1)


def shade(height, albedo, strength=6.0, light=(-0.55, -0.65, 0.52), spec=0.0, shin=24, ambient=0.35, ao_k=4.0):
    """Lambert + Blinn lighting from a heightmap. height: HxW, albedo: HxWx3 in 0..1."""
    gy, gx = np.gradient(height * strength)
    n = np.stack([-gx, -gy, np.ones_like(gx)], -1)
    n /= np.linalg.norm(n, axis=-1, keepdims=True)
    L = np.array(light, np.float32)
    L /= np.linalg.norm(L)
    diff = np.clip((n * L).sum(-1), 0, 1)
    V = np.array([0, 0, 1.0], np.float32)
    H = (L + V)
    H /= np.linalg.norm(H)
    sp = np.clip((n * H).sum(-1), 0, 1) ** shin
    # cavity / ambient occlusion from local height vs. blurred height
    ao = np.clip(0.75 + (height - blur(height, 6)) * ao_k, 0.35, 1.15)
    col = albedo * (ambient + (1 - ambient) * diff[..., None]) * ao[..., None]
    if np.ndim(spec) == 0:
        col = col + spec * sp[..., None]
    else:
        col = col + (spec * sp)[..., None]
    return np.clip(col, 0, 1)


def blobs(h, w, n, rmin, rmax, seed=0, power=1.0):
    """Heightmap made of many rounded bumps (grains, crumbs, lumps)."""
    r = rng(seed)
    out = np.zeros((h, w), np.float32)
    for _ in range(n):
        rad = r.uniform(rmin, rmax)
        cx, cy = r.uniform(0, w), r.uniform(0, h)
        x0, x1 = int(max(0, cx - rad)), int(min(w, cx + rad + 1))
        y0, y1 = int(max(0, cy - rad)), int(min(h, cy + rad + 1))
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        d = ((xx - cx) ** 2 + (yy - cy) ** 2) / rad ** 2
        bump = np.sqrt(np.clip(1 - d, 0, 1)) * rad ** power
        out[y0:y1, x0:x1] = np.maximum(out[y0:y1, x0:x1], bump * r.uniform(0.7, 1.0))
    return out


def ellipse_mask(h, w, cx, cy, rx, ry, edge_noise=0.0, seed=0, soft=1.5):
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.sqrt(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2)
    if edge_noise:
        ang = np.arctan2((yy - cy) / ry, (xx - cx) / rx)
        nz = value_noise(1, 720, 6, seed)[0]
        idx = ((ang + np.pi) / (2 * np.pi) * 719).astype(int)
        d = d - (nz[idx] - 0.5) * edge_noise
    px = soft / max(rx, ry)
    return np.clip((1 - d) / px + 0.5, 0, 1)


def to_img(rgb, alpha):
    a = np.dstack([np.clip(rgb, 0, 1), np.clip(alpha, 0, 1)])
    return Image.fromarray((a * 255).astype(np.uint8), 'RGBA')


def over(dst_rgb, dst_a, src_rgb, src_a):
    """Alpha-composite src over dst (all float arrays)."""
    out_a = src_a + dst_a * (1 - src_a)
    safe = np.where(out_a > 1e-6, out_a, 1)
    out_rgb = (src_rgb * src_a[..., None] + dst_rgb * (dst_a * (1 - src_a))[..., None]) / safe[..., None]
    return out_rgb, out_a


def tube(canvas_rgb, canvas_a, pts, radius, color, seed=0, rings=0.0, ring_period=6.0,
         spec=0.5, shin=30, light=(-0.5, -0.7, 0.5), band=None, taper=True, wet=0.0):
    """Render a shaded tube (worm, straw) along polyline pts onto float canvas in place."""
    pts = np.asarray(pts, np.float32)
    h, w = canvas_a.shape
    pad = radius + 3
    x0, y0 = np.floor(pts.min(0) - pad).astype(int)
    x1, y1 = np.ceil(pts.max(0) + pad).astype(int)
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(w, x1), min(h, y1)
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    best = np.full(xx.shape, 1e9, np.float32)
    tpar = np.zeros_like(best)
    side = np.zeros_like(best)
    seglen = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    cum = np.concatenate([[0], np.cumsum(seglen)])
    total = cum[-1] if cum[-1] > 0 else 1
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        ab = b - a
        L2 = float((ab ** 2).sum()) or 1e-6
        t = np.clip(((xx - a[0]) * ab[0] + (yy - a[1]) * ab[1]) / L2, 0, 1)
        px, py = a[0] + t * ab[0], a[1] + t * ab[1]
        d = np.hypot(xx - px, yy - py)
        cross = (ab[0] * (yy - a[1]) - ab[1] * (xx - a[0])) / np.sqrt(L2)
        m = d < best
        best = np.where(m, d, best)
        tpar = np.where(m, (cum[i] + t * seglen[i]) / total, tpar)
        side = np.where(m, np.sign(cross), side)
    if taper:
        rad = radius * (0.55 + 0.45 * np.sin(np.clip(tpar, 0, 1) * np.pi) ** 0.35)
    else:
        rad = np.full_like(best, radius)
    n = np.clip(best / rad, 0, 1.2)
    inside = np.clip(rad - best + 0.5, 0, 1)
    if not inside.any():
        return
    # pseudo-normal of a cylinder: across-axis component signed by side
    nz = np.sqrt(np.clip(1 - n ** 2, 0, 1))
    # light mostly from top-left: brighten the side that faces up
    tilt = -side * n
    L = np.array(light, np.float32)
    L /= np.linalg.norm(L)
    diff = np.clip(0.55 * nz + 0.45 * tilt * 0.9 + 0.2, 0, 1.2)
    col = np.array(color, np.float32)[None, None, :] * np.ones(xx.shape + (3,), np.float32)
    if band is not None:  # clitellum on worms
        bc, bpos, bw = band
        bm = np.exp(-((tpar - bpos) / bw) ** 2)[..., None]
        col = col * (1 - bm) + np.array(bc, np.float32) * bm
    if rings:
        arc = tpar * total
        ring = 0.5 + 0.5 * np.cos(arc / ring_period * 2 * np.pi)
        col = col * (1 - rings * ring[..., None] * 0.5)
    nzv = value_noise(y1 - y0, x1 - x0, 3, seed)
    col = col * (0.88 + 0.24 * nzv[..., None])
    rim = (n > 0.82) * 0.25
    col = col * (0.25 + 0.85 * diff[..., None]) * (1 - rim[..., None])
    hl = np.exp(-((n - 0.42) / 0.16) ** 2) * (tilt > 0) * spec
    hl += wet * np.exp(-((n - 0.25) / 0.08) ** 2) * (tilt > 0)
    col = col + hl[..., None]
    sub_rgb = canvas_rgb[y0:y1, x0:x1]
    sub_a = canvas_a[y0:y1, x0:x1]
    r_, a_ = over(sub_rgb, sub_a, np.clip(col, 0, 1), inside)
    canvas_rgb[y0:y1, x0:x1] = r_
    canvas_a[y0:y1, x0:x1] = a_


def hex2rgb(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)], np.float32)


def palette_mix(t, cols):
    """Map t in 0..1 onto a list of hex colours."""
    cols = np.stack([hex2rgb(c) for c in cols])
    t = np.clip(t, 0, 1) * (len(cols) - 1)
    i = np.clip(np.floor(t).astype(int), 0, len(cols) - 2)
    f = (t - i)[..., None]
    return cols[i] * (1 - f) + cols[i + 1] * f


def warp(a, amt, cell=10, seed=0):
    """Domain-warp an array with smooth noise offsets (makes round blobs irregular)."""
    h, w = a.shape[:2]
    dx = (fbm(h, w, cell, 3, seed) - 0.5) * 2 * amt
    dy = (fbm(h, w, cell, 3, seed + 99) - 0.5) * 2 * amt
    yy, xx = np.mgrid[0:h, 0:w]
    xs = np.clip((xx + dx).astype(int), 0, w - 1)
    ys = np.clip((yy + dy).astype(int), 0, h - 1)
    return a[ys, xs]


def crumbs(h, w, seed, cols, agg=1400, fine=6000, amin=2.5, amax=8, rough=1.6, strength=0.9, spec=0.03, ambient=0.28):
    """Realistic soil / compost crumb texture."""
    a = blobs(h, w, agg, amin, amax, seed, power=1.0)
    a = warp(a, amax * 0.6, cell=amax * 1.2, seed=seed + 5)
    a = a ** 0.8
    f = blobs(h, w, fine, 0.7, 2.2, seed + 1, power=1.0)
    hgt = np.maximum(a, f * 0.9) + value_noise(h, w, 1.6, seed + 6) * rough + fbm(h, w, 60, 4, seed + 2) * 4
    tone = warp(value_noise(h, w, 6, seed + 3), 4, 8, seed + 7) * 0.6 + fbm(h, w, 50, 4, seed + 4) * 0.4
    alb = palette_mix(tone, cols) * (0.85 + 0.3 * value_noise(h, w, 1.5, seed + 8))[..., None]
    return shade(hgt, alb, strength=strength, spec=spec, ambient=ambient)
