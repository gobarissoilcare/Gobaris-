"""Render each vermicompost-bed layer as a realistic-looking floating disc (RGBA PNG).

Usage:  python3 layers.py OUT_DIR [layer ...]
Layers: jute water worms dung straw bedding drainage bed bed_empty
Convert the PNGs to WebP in ../img/, then run embed_bed.py to put them in index.html.
"""
import sys, os
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(__file__))
from lib import *

OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
os.makedirs(OUT, exist_ok=True)
ONLY = set(sys.argv[2:])

RX, RY = 400, 92          # projected disc radii (px)
S = 2 * RX                 # texture size
MARGIN = 46
TOPM = 70                  # extra room above for things that stick up


def canvas(thick):
    W = 2 * RX + 2 * MARGIN
    H = TOPM + 2 * RY + thick + MARGIN
    return W, H, W / 2, TOPM + RY


def project(tex):
    """Squash a square top texture into the ellipse's bounding box."""
    im = Image.fromarray((np.clip(tex, 0, 1) * 255).astype(np.uint8), 'RGB')
    im = im.resize((2 * RX, 2 * RY), Image.LANCZOS)
    return np.asarray(im, np.float32) / 255.0


def disc(top_tex, side_tex_fn, thick, edge_noise=0.02, seed=0):
    """Return float rgb/alpha canvas with a solid disc: textured top + shaded side wall."""
    W, H, cx, cy = canvas(thick)
    rgb = np.zeros((H, W, 3), np.float32)
    a = np.zeros((H, W), np.float32)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    top_m = ellipse_mask(H, W, cx, cy, RX, RY, edge_noise, seed)
    if thick > 0:
        bot_m = ellipse_mask(H, W, cx, cy + thick, RX, RY, edge_noise, seed)
        band = ((np.abs(xx - cx) <= RX * (1 - edge_noise * 0.3)) & (yy >= cy) & (yy <= cy + thick)).astype(np.float32)
        side_m = np.maximum(bot_m, band * ellipse_mask(H, W, cx, cy, RX, 10 * RY, edge_noise, seed))
        side = side_tex_fn(H, W)
        u = (xx - cx) / RX
        cyl = 0.42 + 0.5 * np.clip(np.cos((u + 0.35) * 1.25), 0, 1)
        depth = np.clip((yy - (cy + RY * np.sqrt(np.clip(1 - u ** 2, 0, 1)))) / max(thick, 1), 0, 1)
        side = side * cyl[..., None] * (0.78 + 0.22 * depth[..., None])
        rgb, a = over(rgb, a, side, side_m)
    top = np.zeros((H, W, 3), np.float32)
    top[TOPM:TOPM + 2 * RY, int(cx - RX):int(cx + RX)] = project(top_tex)
    # gentle rim darkening so the top reads as a surface with an edge
    d = np.sqrt(((xx - cx) / RX) ** 2 + ((yy - cy) / RY) ** 2)
    top = top * (1 - 0.28 * np.clip((d - 0.82) / 0.18, 0, 1) ** 2)[..., None]
    rgb, a = over(rgb, a, top, top_m)
    return rgb, a, (W, H, cx, cy)


def sample_ellipse(r, n, cx, cy, rx, ry):
    ang = r.uniform(0, 2 * np.pi, n)
    rad = np.sqrt(r.uniform(0, 1, n))
    return cx + np.cos(ang) * rad * rx, cy + np.sin(ang) * rad * ry


def save(name, rgb, a):
    to_img(rgb, a).save(os.path.join(OUT, name + '.png'))
    print('saved', name)


def want(name):
    return not ONLY or name in ONLY


# ----------------------------------------------------------------- bedding (soil + coco peat)
def soil_tex(h, w, seed, cols, grains=9000, gmin=1.4, gmax=4.5, spec=0.04):
    hgt = blobs(h, w, grains, gmin, gmax, seed, power=0.8) * 0.35 + fbm(h, w, 90, 5, seed + 1) * 3.0
    tone = fbm(h, w, 70, 4, seed + 2) * 0.6 + value_noise(h, w, 3, seed + 3) * 0.4
    alb = palette_mix(tone, cols)
    return shade(hgt, alb, strength=2.2, spec=spec, ambient=0.32)


def side_soil(cols, seed):
    def f(h, w):
        t = fbm(h, w, 40, 4, seed) * 0.6 + blur(value_noise(h, w, 4, seed + 9), 1) * 0.4
        hgt = blobs(h, w, 2500, 1.2, 3.5, seed + 4) * 0.5 + t * 2
        return shade(hgt, palette_mix(t, cols), strength=1.6, ambient=0.4) * 0.8
    return f


if want('bedding'):
    tex = crumbs(S, S, 21, ['#1a1008', '#2f1e10', '#4a301b', '#62412a', '#3b2614'], agg=5600, fine=24000)
    rgb, a, (W, H, cx, cy) = disc(tex, side_soil(['#140c06', '#26180c', '#3a2716'], 22), 34, 0.015, 3)
    r = rng(23)
    for _ in range(260):   # coco peat fibres
        x, y = sample_ellipse(r, 1, cx, cy, RX * 0.95, RY * 0.92)
        ang = r.uniform(0, np.pi * 2)
        L = r.uniform(6, 18)
        d = np.array([np.cos(ang), np.sin(ang) * 0.3])
        p0 = np.array([x[0], y[0]])
        pts = [p0, p0 + d * L / 2 + r.normal(0, 1.5, 2), p0 + d * L]
        tube(rgb, a, pts, r.uniform(0.6, 1.1), hex2rgb(['#5e321a', '#6e3d21', '#4f2a15', '#7a4627'][r.integers(4)]),
             seed=int(r.integers(1e6)), spec=0.08, taper=True)
    save('bedding', rgb, a)

# ----------------------------------------------------------------- cow dung
if want('dung'):
    h = w = S
    lump = blur(blobs(h, w, 104, 28, 70, 9, power=1.0), 8)
    lump = blur(warp(lump, 16, 40, 3), 2)
    fine = blobs(h, w, 10000, 1.0, 3.0, 30, 1.0)
    hgt = lump * 0.55 + fbm(h, w, 30, 5, 10) * 10 + fine * 0.35 + value_noise(h, w, 2, 4) * 0.5
    tone = fbm(h, w, 45, 5, 13) * 0.7 + value_noise(h, w, 5, 15) * 0.3
    alb = palette_mix(tone, ['#2a1b0d', '#3e2a15', '#54391d', '#684a26', '#77572e'])
    wet = np.clip(fbm(h, w, 70, 3, 14) * 2 - 0.6, 0, 1) * 0.28
    tex = shade(hgt, alb, strength=0.9, spec=wet, shin=35, ambient=0.3, ao_k=0.08)
    rgb, a, (W, H, cx, cy) = disc(tex, side_soil(['#170d06', '#2a190c', '#3d2614'], 37), 40, 0.035, 5)
    r = rng(38)
    for _ in range(320):   # undigested grass fibres
        x, y = sample_ellipse(r, 1, cx, cy, RX * 0.95, RY * 0.9)
        ang = r.uniform(0, np.pi * 2)
        L = r.uniform(5, 14)
        p0 = np.array([x[0], y[0]])
        p1 = p0 + np.array([np.cos(ang), np.sin(ang) * 0.35]) * L
        tube(rgb, a, [p0, p1], r.uniform(0.5, 0.9), hex2rgb(['#7c6038', '#8a6c40', '#5f4a2b'][r.integers(3)]) * 0.8,
             seed=int(r.integers(1e6)), spec=0.1, taper=True)
    save('dung', rgb, a)

# ----------------------------------------------------------------- dry leaves + straw
if want('straw'):
    h = w = S
    base_t = fbm(h, w, 50, 5, 41)
    base = shade(fbm(h, w, 30, 5, 42) * 3, palette_mix(base_t, ['#2a1d0e', '#46321a', '#5e4524']), strength=1.5, ambient=0.35)
    # dried leaves painted in texture space (supersampled)
    r = rng(43)
    ss = 2
    leaf_img = Image.new('RGBA', (w * ss, h * ss), (0, 0, 0, 0))
    dr = ImageDraw.Draw(leaf_img)
    leaf_cols = ['#8b5a2b', '#a0682f', '#6e4521', '#b37a3c', '#7d4f26', '#c08a4a', '#5f3b1c']
    for _ in range(260):
        cx0, cy0 = r.uniform(0, w) * ss, r.uniform(0, h) * ss
        Lf, Wf = r.uniform(28, 60) * ss, r.uniform(10, 22) * ss
        ang = r.uniform(0, np.pi * 2)
        t = np.linspace(0, 1, 24)
        curl = r.uniform(-0.25, 0.25)
        top = [(t_ * Lf, np.sin(t_ * np.pi) * Wf / 2 * (1 + curl * t_)) for t_ in t]
        bot = [(t_ * Lf, -np.sin(t_ * np.pi) * Wf / 2 * (1 - curl * t_)) for t_ in t[::-1]]
        pts = top + bot
        ca, sa = np.cos(ang), np.sin(ang)
        P = [(cx0 + x * ca - y * sa, cy0 + x * sa + y * ca) for x, y in pts]
        c = hex2rgb(leaf_cols[r.integers(len(leaf_cols))]) * r.uniform(0.8, 1.1)
        dr.polygon(P, fill=tuple(int(v * 255) for v in np.clip(np.append(c, 1), 0, 1)))
        vein = [(cx0 + x * ca, cy0 + x * sa) for x in (0, Lf)]
        dr.line(vein, fill=tuple(int(v * 255) for v in np.clip(np.append(c * 0.6, 0.9), 0, 1)), width=2 * ss)
    leaf_img = leaf_img.resize((w, h), Image.LANCZOS)
    la = np.asarray(leaf_img, np.float32) / 255.0
    leaf_h = blur(la[..., 3], 2) * 3 + fbm(h, w, 12, 3, 44) * la[..., 3] * 2
    leaf_rgb = shade(leaf_h, la[..., :3], strength=2.5, spec=0.06, ambient=0.4)
    tex, _ = over(base, np.ones((h, w), np.float32), leaf_rgb, la[..., 3])
    rgb, a, (W, H, cx, cy) = disc(tex, side_soil(['#20160a', '#3a2a14', '#56401f'], 45), 22, 0.03, 7)
    r = rng(46)
    straw_cols = ['#d4ad5c', '#c49a48', '#dfc07a', '#b48c45', '#cfae68', '#a78343', '#e2c886', '#bd9a58']
    for i in range(240):
        x, y = sample_ellipse(r, 1, cx, cy - 4, RX * 0.98, RY * 0.95)
        ang = r.uniform(0, np.pi * 2)
        L = r.uniform(30, 100) * (0.55 + 0.45 * abs(np.cos(ang)))
        d = np.array([np.cos(ang), np.sin(ang) * 0.3])
        p0 = np.array([x[0], y[0]]) - d * L / 2
        bend = r.normal(0, 3, 2)
        pts = [p0, p0 + d * L * 0.5 + bend, p0 + d * L]
        tube(rgb, a, pts, r.uniform(2.4, 4.0), hex2rgb(straw_cols[r.integers(len(straw_cols))]) * r.uniform(0.8, 1.02),
             seed=int(r.integers(1e6)), spec=0.3, taper=False, rings=0.1, ring_period=r.uniform(30, 60))
    save('straw', rgb, a)

# ----------------------------------------------------------------- jute cover
def stretched_noise(h, w, cx_, cy_, seed):
    small = value_noise(max(2, int(h / cy_)), max(2, int(w / cx_)), 1, seed)
    return np.asarray(Image.fromarray((small * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC), np.float32) / 255


if want('jute'):
    h = w = S
    sp = 20
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    drape = fbm(h, w, 160, 4, 51)
    wx = warp(xx, 2.5, 40, 52)
    wy = warp(yy, 2.5, 40, 53)
    ix, iy = np.floor(wx / sp), np.floor(wy / sp)
    fx, fy = (wx % sp) / sp, (wy % sp) / sp
    r = rng(54)
    thick_x = 0.8 + 0.4 * r.random(int(w / sp) + 4)
    thick_y = 0.8 + 0.4 * r.random(int(h / sp) + 4)
    tx = thick_x[np.clip(ix.astype(int), 0, len(thick_x) - 1)]
    ty = thick_y[np.clip(iy.astype(int), 0, len(thick_y) - 1)]
    warp_p = np.clip(np.sin(np.pi * np.clip((fx - 0.5) / tx + 0.5, 0, 1)), 0, 1) ** 0.6
    weft_p = np.clip(np.sin(np.pi * np.clip((fy - 0.5) / ty + 0.5, 0, 1)), 0, 1) ** 0.6
    chk = ((ix + iy) % 2) == 0
    warp_h = warp_p * (1.0 + 0.6 * np.sin(np.pi * fy) * chk)
    weft_h = weft_p * (1.0 + 0.6 * np.sin(np.pi * fx) * (~chk))
    top_is_warp = np.where(chk, warp_h >= weft_h * 0.7, warp_h > weft_h * 1.3)
    thread_h = np.maximum(warp_h, weft_h)
    hair_v = stretched_noise(h, w, 1.2, 7, 55)
    hair_h = stretched_noise(h, w, 7, 1.2, 56)
    hair = np.where(top_is_warp, hair_v, hair_h)
    hgt = thread_h * 5.0 + hair * 1.2 + drape * 40
    gap = np.clip(1 - thread_h * 2.2, 0, 1)
    tvar = np.where(top_is_warp, thick_x[np.clip(ix.astype(int), 0, len(thick_x) - 1)], thick_y[np.clip(iy.astype(int), 0, len(thick_y) - 1)])
    tone = (tvar - 0.8) / 0.4 * 0.5 + hair * 0.35 + fbm(h, w, 90, 3, 57) * 0.3
    alb = palette_mix(tone, ['#8a6738', '#a37f4a', '#b8935c', '#c9a46c'])
    alb = alb * (1 - gap[..., None] * 0.85)
    tex = shade(hgt, alb, strength=1.1, spec=0.04, ambient=0.4, ao_k=0.5)
    def jside(h_, w_):
        t = stretched_noise(h_, w_, 1.5, 6, 58)
        return palette_mix(t, ['#5a4222', '#7a5a30', '#8f6c3c']) * 0.8
    rgb, a, (W, H, cx, cy) = disc(tex, jside, 10, 0.04, 9)
    r = rng(59)
    for _ in range(420):   # frayed fibres around the edge
        ang = r.uniform(0, 2 * np.pi)
        ex, ey = cx + np.cos(ang) * RX * 0.985, cy + np.sin(ang) * RY * 0.985 + 4
        L = r.uniform(6, 22)
        d = np.array([np.cos(ang + r.normal(0, 0.35)), np.sin(ang + r.normal(0, 0.35)) * 0.5])
        p0 = np.array([ex, ey])
        pts = [p0, p0 + d * L * 0.5 + r.normal(0, 1.2, 2), p0 + d * L]
        tube(rgb, a, pts, r.uniform(0.4, 0.8), hex2rgb(['#b8935c', '#a37f4a', '#c9a46c'][r.integers(3)]),
             seed=int(r.integers(1e6)), spec=0.05, taper=True)
    save('jute', rgb, a)

# ----------------------------------------------------------------- water
def droplet(rgb, a, x, y, r_, stretch=1.0):
    h, w = a.shape
    x0, x1 = int(max(0, x - r_ - 2)), int(min(w, x + r_ + 3))
    y0, y1 = int(max(0, y - r_ * stretch - 2)), int(min(h, y + r_ * stretch + 3))
    if x1 <= x0 or y1 <= y0:
        return
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    dx, dy = (xx - x) / r_, (yy - y) / (r_ * stretch)
    n = np.sqrt(dx ** 2 + dy ** 2)
    inside = np.clip((1 - n) * r_ + 0.5, 0, 1)
    rim = np.clip((n - 0.55) / 0.4, 0, 1) ** 1.5
    col = np.zeros(xx.shape + (3,), np.float32) + np.array([0.70, 0.82, 0.86])
    col = col * (1 - rim[..., None] * 0.8) + np.array([0.06, 0.10, 0.12]) * rim[..., None] * 0.8
    al = inside * (0.22 + 0.65 * rim)
    hl = np.exp(-(((dx + 0.33) ** 2 + (dy + 0.38) ** 2) / 0.035))
    ca = np.exp(-((n - 0.62) / 0.12) ** 2) * np.clip(dx + dy, 0, 1)
    col = col + (hl * 1.2 + ca * 0.55)[..., None]
    al = np.clip(al + inside * (hl * 0.95 + ca * 0.4), 0, 1)
    r2, a2 = over(rgb[y0:y1, x0:x1], a[y0:y1, x0:x1], np.clip(col, 0, 1), al)
    rgb[y0:y1, x0:x1] = r2
    a[y0:y1, x0:x1] = a2


if want('water'):
    W, H, cx, cy = canvas(0)
    rgb = np.zeros((H, W, 3), np.float32)
    a = np.zeros((H, W), np.float32)
    r = rng(61)
    for _ in range(70):   # faint motion trails above the larger drops
        x, y = sample_ellipse(r, 1, cx, cy, RX * 0.95, RY * 0.85)
        L = r.uniform(10, 26)
        tube(rgb, a, [(x[0], y[0] - L), (x[0], y[0] - L / 2), (x[0], y[0])], r.uniform(0.8, 1.6),
             np.array([0.8, 0.9, 0.95]), seed=int(r.integers(1e6)), spec=0.2, taper=True)
    a *= 0.45   # trails stay faint
    # a layer of drops falling across the whole disc
    for _ in range(420):
        x, y = sample_ellipse(r, 1, cx, cy, RX * 1.0, RY * 0.95)
        rr = float(np.clip(r.pareto(2.0) * 2.4 + 2, 2, 14))
        droplet(rgb, a, x[0], y[0], rr, r.uniform(1.0, 1.25))
    for _ in range(60):   # tiny mist
        x, y = sample_ellipse(r, 1, cx, cy, RX * 1.05, RY * 1.05)
        droplet(rgb, a, x[0], y[0], r.uniform(1.2, 2.2))
    save('water', rgb, a)

# ----------------------------------------------------------------- earthworms
if want('worms'):
    W, H, cx, cy = canvas(0)
    rgb = np.zeros((H, W, 3), np.float32)
    a = np.zeros((H, W), np.float32)
    # a scatter of soil crumbs the worms are moving through
    crumb_tex = crumbs(H, W, 71, ['#1a1008', '#2f1e10', '#4a301b', '#3b2614'], agg=900, fine=3000)
    cm = blobs(H, W, 700, 2, 6, 72, power=0.0)
    cm = (cm > 0).astype(np.float32) * ellipse_mask(H, W, cx, cy + 6, RX * 0.85, RY * 0.8)
    rgb, a = over(rgb, a, crumb_tex, blur(cm, 0.6))
    r = rng(73)
    body = ['#6e2a2c', '#7c3134', '#8a3a3a', '#743028', '#80362f']
    for i in range(10):
        x, y = sample_ellipse(r, 1, cx, cy, RX * 0.6, RY * 0.55)
        hd = r.uniform(0, 2 * np.pi)
        L = r.uniform(230, 360)
        n = 60
        amp, freq, ph = r.uniform(0.5, 1.1), r.uniform(1.0, 2.2), r.uniform(0, 6)
        pts = [np.array([x[0], y[0]])]
        step = L / n
        for k in range(n):
            t = k / n
            hh = hd + amp * np.sin(2 * np.pi * freq * t + ph)
            pts.append(pts[-1] + np.array([np.cos(hh), np.sin(hh) * 0.45]) * step)
        pts = np.array(pts)
        pts -= (pts.mean(0) - np.array([x[0], y[0]])) * 0.6
        rad = r.uniform(7.0, 9.0)
        col = hex2rgb(body[r.integers(len(body))])
        tube(rgb, a, pts, rad, col, seed=int(r.integers(1e6)), rings=0.22, ring_period=3.6,
             spec=0.14, wet=0.22, band=(hex2rgb('#b86a5c'), r.choice([0.25, 0.75]), 0.06), taper=True)
    save('worms', rgb, a)

# ----------------------------------------------------------------- drainage base: sand + broken bricks
def brick_piece(rgb, a, cx0, cy0, w0, h0, depth, ang, seed):
    r = rng(seed)
    ss = 2
    hw, hh = w0 / 2, h0 / 2
    base = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
    pts = []
    for i in range(4):
        p, q = np.array(base[i]), np.array(base[(i + 1) % 4])
        for t in np.linspace(0, 1, 4, endpoint=False):
            v = p + (q - p) * t
            v = v * r.uniform(0.82, 1.0) + r.normal(0, 1.6, 2)
            pts.append(v)
    ca, sa = np.cos(ang), np.sin(ang)
    P = np.array([(cx0 + x * ca - y * sa, cy0 + (x * sa + y * ca) * 0.45) for x, y in pts])
    x0, y0 = np.floor(P.min(0) - 3).astype(int)
    x1, y1 = np.ceil(P.max(0) + depth + 4).astype(int)
    H_, W_ = a.shape
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W_, x1), min(H_, y1)
    bw, bh = x1 - x0, y1 - y0
    if bw <= 2 or bh <= 2:
        return
    topm = Image.new('L', (bw * ss, bh * ss), 0)
    sidem = Image.new('L', (bw * ss, bh * ss), 0)
    dt, ds = ImageDraw.Draw(topm), ImageDraw.Draw(sidem)
    Q = [((x - x0) * ss, (y - y0) * ss) for x, y in P]
    for k in range(int(depth) + 1):
        ds.polygon([(x, y + k * ss) for x, y in Q], fill=255)
    dt.polygon(Q, fill=255)
    tm = np.asarray(topm.resize((bw, bh), Image.LANCZOS), np.float32) / 255
    sm = np.asarray(sidem.resize((bw, bh), Image.LANCZOS), np.float32) / 255
    hue = r.integers(4)
    base_c = hex2rgb(['#a4532f', '#93452a', '#b2623b', '#8a3f25'][hue])
    nz = value_noise(bh, bw, 2, seed + 1) * 0.6 + value_noise(bh, bw, 6, seed + 2) * 0.4
    pores = (value_noise(bh, bw, 1.5, seed + 3) > 0.9) * 0.18
    top_c = base_c * (0.8 + 0.4 * nz[..., None]) * (1 - pores[..., None])
    hgt = nz * 1.2 + pores * -1
    top_c = shade(hgt, np.clip(top_c * 1.05, 0, 1), strength=1.0, ambient=0.55, ao_k=0.5)
    yy = np.mgrid[0:bh, 0:bw][0].astype(np.float32) / bh
    side_c = base_c * (0.5 - 0.15 * yy[..., None]) * (0.85 + 0.3 * nz[..., None])
    r2, a2 = over(rgb[y0:y1, x0:x1], a[y0:y1, x0:x1], side_c, sm)
    r2, a2 = over(r2, a2, top_c, tm)
    rgb[y0:y1, x0:x1] = r2
    a[y0:y1, x0:x1] = a2


if want('drainage'):
    g = blobs(S, S, 60000, 0.7, 1.8, 81, 1.0)
    hgt = g * 0.6 + fbm(S, S, 80, 5, 84) * 9 + value_noise(S, S, 1.3, 85) * 0.8
    tone = fbm(S, S, 60, 4, 86) * 0.5 + value_noise(S, S, 1.4, 87) * 0.5
    alb = palette_mix(tone, ['#a58c64', '#b8a077', '#c8b088', '#d3bd96', '#bea67c'])
    peb = blobs(S, S, 380, 3, 7, 88, 1.0)
    pm = (peb > 0.5).astype(np.float32)
    alb = alb * (1 - pm[..., None]) + palette_mix(value_noise(S, S, 6, 89), ['#6d6255', '#857766', '#9a8b76', '#5d5246']) * pm[..., None]
    hgt = hgt + peb * 0.8
    tex = shade(hgt, alb, strength=0.9, spec=0.03, ambient=0.5, ao_k=0.6)
    rgb, a, (W, H, cx, cy) = disc(tex, side_soil(['#6f5a3a', '#8d7550', '#a48a62'], 82), 26, 0.02, 11)
    r = rng(83)
    pieces = []
    for i in range(40):
        x, y = sample_ellipse(r, 1, cx, cy - 6, RX * 0.84, RY * 0.74)
        pieces.append((y[0], x[0], r.uniform(34, 74), r.uniform(22, 42), r.uniform(10, 17), r.uniform(0, np.pi), int(r.integers(1e6))))
    for y, x, w0, h0, dep, ang, sd in sorted(pieces):
        brick_piece(rgb, a, x, y - dep, w0, h0, dep, ang, sd)
    save('drainage', rgb, a)

# ----------------------------------------------------------------- finished brick bed
def poly_mask(h, w, pts, ss=2):
    m = Image.new('L', (w * ss, h * ss), 0)
    ImageDraw.Draw(m).polygon([(x * ss, y * ss) for x, y in pts], fill=255)
    return np.asarray(m.resize((w, h), Image.LANCZOS), np.float32) / 255


def brick_wall(h, w, bw, bh, mortar, seed, light=1.0, offset=0):
    """Running-bond brick texture with mortar recesses, lit from top-left."""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    row = np.floor((yy + offset) / bh)
    sx = xx + (row % 2) * bw / 2
    col = np.floor(sx / bw)
    fx, fy = sx % bw, (yy + offset) % bh
    edge = np.minimum(np.minimum(fx, bw - fx), np.minimum(fy, bh - fy))
    brick = np.clip((edge - mortar / 2) / 2.5, 0, 1)
    r = rng(seed)
    ids = (row * 997 + col * 131).astype(np.int64) % 4096
    lut = r.random(4096)
    pal = ['#8e3f25', '#9d4a2d', '#a85637', '#7f3720', '#b2603d', '#94462b']
    bc = palette_mix(lut[ids], pal)
    nz = value_noise(h, w, 2, seed + 1) * 0.5 + value_noise(h, w, 7, seed + 2) * 0.5
    bc = bc * (0.82 + 0.3 * nz[..., None])
    mc = palette_mix(value_noise(h, w, 3, seed + 3), ['#a99d86', '#bcb19b', '#cbc0aa'])
    alb = bc * brick[..., None] + mc * (1 - brick[..., None])
    hgt = brick * 3 + nz * 0.8
    return shade(hgt, alb, strength=0.9, ambient=0.55, ao_k=0.15) * light


for variant in ('bed', 'bed_empty'):
  if want(variant):
      W, H = 1000, 560
      rgb = np.zeros((H, W, 3), np.float32)
      a = np.zeros((H, W), np.float32)
      FL, FR, FY = 60, 940, 300          # front top outer edge
      BL, BR, BY = 150, 850, 150         # back top outer edge
      t_front, t_back = 24, 13
      IFL, IFR, IFY = FL + 22, FR - 22, FY - t_front
      IBL, IBR, IBY = BL + 15, BR - 15, BY + t_back
      BOTTOM = 520
      # inner walls (in shade)
      inner = poly_mask(H, W, [(IFL, IFY), (IFR, IFY), (IBR, IBY), (IBL, IBY)])
      inner_tex = brick_wall(H, W, 70, 22, 4, 101, light=0.42)
      rgb, a = over(rgb, a, inner_tex, inner)
      # compost surface, slightly below the rim
      CB = IBY + 26
      comp_pts = [(IFL - 4, IFY + 14), (IFR + 4, IFY + 14), (IBR - 6, CB), (IBL + 6, CB)]
      cm = poly_mask(H, W, comp_pts) * inner
      comp = crumbs(H, W, 102, ['#120b06', '#1e140b', '#2b1d11', '#3a2817', '#24180d'], agg=7000, fine=16000,
                    amin=1.6, amax=4.6, rough=1.0, strength=0.9, ambient=0.3)
      yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
      depth_shade = np.clip((yy - CB) / (IFY - CB), 0, 1)
      comp = comp * (0.62 + 0.38 * depth_shade[..., None])
      # soft shadow cast by the back and side walls onto the compost
      sh = np.clip(1 - (yy - CB) / 40, 0, 1) * 0.5
      comp = comp * (1 - sh[..., None])
      if variant == 'bed':
          rgb, a = over(rgb, a, comp, cm)
      # a few worms on the surface
      r = rng(103)
      for i in range(6 if variant == 'bed' else 0):
          x0 = r.uniform(IFL + 120, IFR - 120)
          y0 = r.uniform(CB + 30, IFY - 16)
          hd = r.uniform(0, 2 * np.pi)
          pts = [np.array([x0, y0])]
          for k in range(30):
              hh = hd + 0.8 * np.sin(k / 30 * 2 * np.pi * 1.3 + i)
              pts.append(pts[-1] + np.array([np.cos(hh), np.sin(hh) * 0.4]) * 4.2)
          tube(rgb, a, pts, 4.6, hex2rgb(['#6e2a2c', '#7c3134', '#743028'][i % 3]), seed=int(r.integers(1e6)),
               rings=0.22, ring_period=3.0, spec=0.12, wet=0.2, band=(hex2rgb('#b86a5c'), 0.3, 0.06))
      # top faces of the walls (brick tops, lit)
      top_tex = brick_wall(H, W, 70, 400, 4, 104, light=1.08)
      for pts in ([(FL, FY), (FR, FY), (IFR, IFY), (IFL, IFY)],
                  [(FL, FY), (IFL, IFY), (IBL, IBY), (BL, BY)],
                  [(FR, FY), (IFR, IFY), (IBR, IBY), (BR, BY)],
                  [(BL, BY), (BR, BY), (IBR, IBY), (IBL, IBY)]):
          rgb, a = over(rgb, a, top_tex, poly_mask(H, W, pts))
      # front face
      front = brick_wall(H, W, 78, 26, 5, 105, light=0.95, offset=-FY)
      grad = np.clip(1 - (yy - FY) / (BOTTOM - FY) * 0.35, 0, 1) * (0.9 + 0.1 * np.cos((xx - W / 2) / W * 2.2))
      front = front * grad[..., None]
      fm = poly_mask(H, W, [(FL, FY), (FR, FY), (FR, BOTTOM), (FL, BOTTOM)])
      rgb, a = over(rgb, a, front, fm)
      # edge highlight along the front top arris
      hlm = poly_mask(H, W, [(FL, FY - 1), (FR, FY - 1), (FR, FY + 2), (FL, FY + 2)])
      rgb, a = over(rgb, a, np.ones_like(rgb) * np.array([0.85, 0.6, 0.45]), hlm * 0.5)
      save(variant, rgb, a)
