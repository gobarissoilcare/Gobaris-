"""Embed the exploded-view vermicompost bed section into index.html (run from the repo root).

Images come from vermicompost-bed/img/*.webp and are inlined as data URIs so the site stays one file.
"""
import base64
import json
SRC = 'index.html'
IMG = 'vermicompost-bed/img/'
EXTENTS = json.load(open(IMG + 'extents.json'))   # written by bake.py (measured before the shadow)


def extent(n):
    """Visible top/bottom of a layer image, relative to its disc centre (image px)."""
    return EXTENTS[n]


def uri(n):
    return 'data:image/webp;base64,' + base64.b64encode(open(IMG + n + '.webp', 'rb').read()).decode()

css = '''
/* ================= EXPLODED VIEW: vermicompost bed (scroll-linked) ================= */
.vb-section{position:relative; height:340vh; padding:0; background:#0F160A;}
.vb-stage{
  position:sticky; top:0; height:100vh; height:100svh; min-height:560px; overflow:hidden;
  background:
    radial-gradient(ellipse 55% 60% at 36% 48%, rgba(232,201,137,0.10), transparent 70%),
    radial-gradient(ellipse 80% 70% at 40% 30%, rgba(88,104,52,0.45), transparent 75%),
    linear-gradient(180deg, #2C3A1C 0%, #1C2713 50%, #0F160A 100%);
}
.vb-stage::after{
  content:''; position:absolute; left:0; right:0; bottom:0; height:16%; pointer-events:none;
  background:radial-gradient(ellipse 70% 100% at 40% 100%, rgba(0,0,0,0.55), transparent 70%);
}
.vb-head{position:absolute; left:0; right:0; top:92px; z-index:5; text-align:center; padding:0 16px; pointer-events:none;}
.vb-head .vb-eyebrow{font-family:'Fraunces', 'Playfair Display', serif; font-weight:700; font-size:clamp(2rem,4vw,3.1rem); line-height:1.05; letter-spacing:-0.01em; color:#E8C989;}
.vb-head h2{margin:8px 0 0; font-family:'Cormorant Garamond', serif; font-style:italic; font-weight:500; line-height:1.3; font-size:clamp(1.25rem,2.1vw,1.65rem); color:#F4EEDF;}
.vb-head h2 em{color:#E39A3B;}
.vb-stage.vb-wide .vb-hint{right:auto; bottom:auto; left:var(--vb-head-left, 40px); top:var(--vb-hint-top, 60%); flex-direction:row; gap:10px;}
.vb-stage.vb-wide .vb-hint i{width:28px; height:1px; background:linear-gradient(90deg, #E8C989, transparent); animation:none;}
.vb-stage.vb-wide .vb-head{right:auto; top:50%; transform:translateY(-50%); text-align:left; padding:0; left:var(--vb-head-left, 40px); width:var(--vb-head-w, 300px);}
.vb-layer, .vb-bed, .vb-label{position:absolute; left:0; top:0;}
.vb-layer, .vb-bed{transform-origin:0 0; pointer-events:none;}
.vb-layer img, .vb-bed img{display:block; width:100%; height:auto; max-width:none; border-radius:0;}
.vb-bed .vb-fill{position:absolute; inset:0;}
.vb-label{display:flex; align-items:flex-start; gap:10px; z-index:30;}
.vb-label .vb-lead{position:relative; flex:none; height:1px; margin-top:0.62em; background:rgba(244,238,223,0.75);}
.vb-label .vb-lead::before{content:''; position:absolute; left:-4px; top:-4px; width:9px; height:9px; border-radius:50%; background:#F4EEDF;}
.vb-label h3{margin:0; font-family:'Space Mono', monospace; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; font-size:clamp(0.78rem,1.35vw,1.02rem); color:#E39A3B; line-height:1.25;}
.vb-label p{margin:4px 0 0; font-family:'Work Sans', sans-serif; font-size:clamp(0.72rem,1.15vw,0.92rem); line-height:1.45; color:rgba(239,230,210,0.72); max-width:30ch;}
.vb-label.vb-bed-label h3{color:#E8C989;}
#page-home .vb-label h3{color:#E39A3B;}
#page-home .vb-label.vb-bed-label h3{color:#E8C989;}
#page-home .vb-head .vb-eyebrow{color:#E8C989;}
#page-home .vb-head h2{color:#F4EEDF;}
#page-home .vb-head h2 em{color:#E39A3B;}
.vb-label .vb-short{display:none;}
.vb-hint{
  position:absolute; right:clamp(16px,4vw,40px); bottom:22px; z-index:31; pointer-events:none;
  font-family:'Space Mono', monospace; font-size:0.72rem; letter-spacing:0.18em; text-transform:uppercase;
  color:#E8C989; display:flex; flex-direction:column; align-items:center; gap:8px;
}
.vb-hint i{display:block; width:1px; height:28px; background:linear-gradient(#E8C989, transparent); animation:vb-drip 1.6s ease-in-out infinite;}
@keyframes vb-drip{0%{transform:scaleY(0); transform-origin:top;} 50%{transform:scaleY(1); transform-origin:top;} 100%{transform:scaleY(0); transform-origin:bottom;}}
@media (prefers-reduced-motion: reduce){ .vb-hint i{animation:none;} }
@media (max-width:759px){
  .vb-head{top:84px;}
  .vb-label .vb-long{display:none;}
  .vb-label .vb-short{display:inline;}
  .vb-label h3{font-size:0.7rem; letter-spacing:0.04em;}
  .vb-label p{font-size:0.72rem; margin-top:2px;}
  .vb-hint{right:auto; left:50%; transform:translateX(-50%); bottom:auto; top:var(--vb-hint-top, 160px); font-size:0.62rem; flex-direction:row; gap:6px; white-space:nowrap;}
  .vb-hint i{display:none;}
}
'''

html = f'''
<!-- ============ EXPLODED VIEW: VERMICOMPOST BED ============ -->
<section class="vb-section" id="bed" aria-label="Exploded view of a vermicompost bed">
  <div class="vb-stage" id="vbStage">
    <div class="vb-head" id="vbHead">
      <div class="vb-eyebrow">The vermicompost bed</div>
      <h2>Seven layers, <em>pulled apart.</em></h2>
    </div>
    <div class="vb-bed" id="vbBed">
      <img class="vb-base" src="{uri('bed_empty')}" alt="" width="1000" height="560">
      <img class="vb-fill" id="vbBedFill" src="{uri('bed')}" alt="A brick vermicompost bed filled with dark, crumbly vermicompost" width="1000" height="560">
    </div>
    <div class="vb-label vb-bed-label" id="vbBedLabel">
      <span class="vb-lead"></span>
      <div><h3>The finished bed</h3><p><span class="vb-long">45&ndash;60 days later: dark, crumbly, earthy-smelling vermicompost.</span><span class="vb-short">Ready in 45&ndash;60 days</span></p></div>
    </div>
    <div class="vb-hint" id="vbHint">Scroll to build the bed<i></i></div>
  </div>
</section>
'''

layers = [
    ('jute', 310, 'Jute cover', 'Keeps the bed dark and moist', 'Keeps the bed dark, cool and moist — worms stay away from sunlight.'),
    ('water', 300, 'Water sprinkle', 'Moisture near 60%', 'Keeps moisture near 60% — damp, like a wrung-out sponge.'),
    ('worms', 300, 'Earthworms', 'Turn the feed into castings', 'Red wigglers eat the feed and leave behind rich castings.'),
    ('dung', 340, 'Cow dung (gobar)', 'Aged 15–20 days, worm food', 'Aged 15–20 days so it’s cool — the main food for the worms.'),
    ('straw', 322, 'Dry leaves & straw', 'Carbon and air pockets', 'Adds carbon and air pockets so the bed can breathe.'),
    ('bedding', 334, 'Bedding layer', 'Soil and coco peat', 'Soil and coco peat — a soft, damp home where worms settle in.'),
    ('drainage', 326, 'Drainage base', 'Lets extra water drain', 'Broken bricks and sand let extra water drain away.'),
]
items = ',\n'.join(
    f"    {{id:'{i}', h:{h}, top:{extent(i)[0]}, bot:{extent(i)[1]}, title:'{t}', short:'{sh}', text:'{tx.replace(chr(39), chr(92)+chr(39))}', src:'{uri(i)}'}}"
    for i, h, t, sh, tx in layers)

js = '''
// ---- Exploded view: vermicompost bed. Scrolling down builds the bed, scrolling up separates it ----
(function(){
  const stage = document.getElementById('vbStage');
  if(!stage) return;
  const LAYERS = [
''' + items + '''
  ];
  // Layer images are 892px wide; each disc is 800px across, centred 162px from the image top.
  const IMG_W = 892, DISC_W = 800, DISC_LEFT = 46, DISC_CY = 162, DISC_RY = 92;
  // Bed image (1000 x 560): outer front wall 60..940, opening centre y ~ 222, rim y ~ 150.
  const BED_W = 1000, BED_OUTER_L = 60, BED_OUTER_W = 880, BED_OPEN_CY = 222, BED_OPEN_W = 836, BED_RIM_Y = 150;
  const section = stage.parentElement;
  const bed = document.getElementById('vbBed');
  const bedFill = document.getElementById('vbBedFill');
  const bedLabel = document.getElementById('vbBedLabel');
  const hint = document.getElementById('vbHint');
  const head = document.getElementById('vbHead');

  const items = LAYERS.map((L, i) => {
    const fig = document.createElement('div');
    fig.className = 'vb-layer';
    fig.innerHTML = `<img src="${L.src}" alt="${L.title} layer" width="${IMG_W}" height="${L.h}" decoding="async">`;
    // if a browser ever fails to decode a layer, load it once more
    const im = fig.querySelector('img');
    if(im.decode) im.decode().catch(() => { const src = im.src; im.src = ''; im.src = src; });
    const lab = document.createElement('div');
    lab.className = 'vb-label';
    lab.innerHTML = `<span class="vb-lead"></span><div><h3>${L.title}</h3><p><span class="vb-long">${L.text}</span><span class="vb-short">${L.short}</span></p></div>`;
    stage.insertBefore(fig, hint);
    stage.insertBefore(lab, hint);
    return {fig, lab, i};
  });

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const ease = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  let G = null;

  const SITE_TOP = 86;                           // clear the site's fixed header
  const BED_TOP = 150, BED_BOT = 520;            // visible rows of the bed image

  function layout(){
    const vw = stage.clientWidth, vh = stage.clientHeight;
    if(!vw || !vh) return;                       // hidden (another page is showing)
    const narrow = vw < 760, wide = vw >= 1100;
    stage.classList.toggle('vb-wide', wide);
    const content = Math.min(vw, 1240), left = (vw - content) / 2;
    const topY = wide ? SITE_TOP : head.offsetTop + head.offsetHeight + (narrow ? 14 : 18);
    const bottomM = narrow ? 30 : 20;
    // every layer gets exactly its own height plus a gap, so neighbours never touch
    const layerPx = LAYERS.reduce((sum, L) => sum + (L.bot - L.top), 0);
    const bedPx = (BED_BOT - BED_TOP) * DISC_W * 1.06 / BED_OUTER_W;
    let m = narrow ? 12 : 22;                  // includes room for each layer's soft shadow
    const mBed = narrow ? 12 : 18;
    const avail = vh - topY - bottomM - mBed - m * (LAYERS.length - 1);
    const maxW = narrow ? vw * 0.54 : wide ? Math.min(content * 0.34, 470) : Math.min(content * 0.44, 470);
    const artW = Math.max(120, Math.min(maxW, DISC_W * avail / (layerPx + bedPx)));
    const s = artW / DISC_W;
    // share out any spare height as extra breathing room between layers
    const spare = avail - (layerPx + bedPx) * s;
    if(spare > 0) m += Math.min(spare / LAYERS.length, narrow ? 20 : 40);
    const artCx = narrow ? 16 + artW / 2 : wide ? left + content * 0.5 : left + content * 0.38;
    const bedScale = (artW * 1.06) / BED_OUTER_W;
    const bedH = 560 * bedScale;
    let cursor = topY;
    const ys = LAYERS.map(L => { const cy = cursor - L.top * s; cursor = cy + L.bot * s + m; return cy; });
    const bedY = cursor - m + mBed - BED_TOP * bedScale;
    const leadW = narrow ? 14 : Math.max(26, Math.min(70, vw * 0.04));
    const labX = artCx + artW / 2 + 10;
    const labW = Math.max(110, vw - labX - (narrow ? 10 : left + 24) - leadW - 10);
    const liftScale = narrow ? Math.min(1.35, (vw * 0.88) / (BED_OUTER_W * bedScale)) : 1.35;
    const midTop = wide ? SITE_TOP : topY;
    G = {vw, narrow, artW, artCx, s, ys, bedScale, bedY, bedH, labX, liftScale,
         openCy: bedY + BED_OPEN_CY * bedScale,
         landS: (BED_OPEN_W * bedScale * 0.96) / DISC_W,
         bedY2: midTop + (vh - midTop) / 2 - bedH * liftScale / 2};
    if(wide){
      stage.style.setProperty('--vb-head-left', (left + 24) + 'px');
      stage.style.setProperty('--vb-head-w', Math.max(220, artCx - artW / 2 - left - 70) + 'px');
    }
    bed.style.width = BED_W + 'px';
    items.forEach(it => { it.fig.style.width = IMG_W + 'px'; });
    stage.querySelectorAll('.vb-label').forEach(l => {
      l.querySelector('.vb-lead').style.width = leadW + 'px';
      l.querySelector('div').style.maxWidth = labW + 'px';
    });
    G.labH = items.map(it => it.lab.offsetHeight);
    const hr = head.getBoundingClientRect(), sr = stage.getBoundingClientRect();
    stage.style.setProperty('--vb-hint-top', (hr.bottom - sr.top + (wide ? 22 : 2)) + 'px');
    update();
  }

  function update(){
    if(!G) return;
    const r = section.getBoundingClientRect();
    const total = section.offsetHeight - stage.clientHeight;
    const p = clamp(-r.top / Math.max(1, total), 0, 1);
    let landed = 0, prevLabBottom = -1e9;
    items.forEach(({fig, lab, i}) => {
      const b = LAYERS.length - 1 - i;            // build order: the drainage base goes in first
      const t = ease(clamp((p - b * 0.06) / 0.5, 0, 1));
      const ySep = G.ys[i];
      const yLand = G.openCy + (b - 3) * 1.2;
      const cy = ySep + (yLand - ySep) * t;
      const sx = G.s + (G.landS - G.s) * t;
      const sy = sx * (1 - 0.38 * t);            // flatten into the bed's opening
      fig.style.transform = `translate(${G.artCx - (DISC_LEFT + DISC_W / 2) * sx}px, ${cy - DISC_CY * sy}px) scale(${sx}, ${sy})`;
      fig.style.opacity = t < 0.72 ? 1 : clamp(1 - (t - 0.72) / 0.28, 0, 1);
      fig.style.zIndex = 10 + (LAYERS.length - i);   // higher layers sit in front of lower ones
      // labels follow their layer, but never sit on top of the label above
      const ly = Math.max(cy - 10, prevLabBottom + 4);
      prevLabBottom = ly + G.labH[i];
      lab.style.transform = `translate(${G.labX}px, ${ly}px)`;
      lab.style.opacity = clamp(1 - t * 1.6, 0, 1);
      landed += clamp((t - 0.7) / 0.3, 0, 1);
    });
    bedFill.style.opacity = clamp(landed / LAYERS.length, 0, 1);
    // once everything is in, the finished bed rises to the middle of the screen
    const lift = ease(clamp((p - 0.86) / 0.14, 0, 1));
    const bs = G.bedScale * (1 + (G.liftScale - 1) * lift);
    const by = G.bedY + (G.bedY2 - G.bedY) * lift;
    const bcx = G.narrow ? G.artCx + (G.vw / 2 - G.artCx) * lift : G.artCx;
    const bx = bcx - (BED_OUTER_L + BED_OUTER_W / 2) * bs;
    bed.style.transform = `translate(${bx}px, ${by}px) scale(${bs})`;
    const bedRight = bx + (BED_OUTER_L + BED_OUTER_W) * bs;
    const bedHNow = G.bedH * (bs / G.bedScale);
    let lx = bedRight + 8, ly = by + bedHNow * 0.5;
    if(G.narrow && lift > 0){                     // phones: the label slides underneath the bed
      lx += (G.vw / 2 - bedLabel.offsetWidth / 2 - lx) * lift;
      ly += (by + bedHNow + 6 - ly) * lift;
    }
    bedLabel.style.transform = `translate(${lx}px, ${ly}px)`;
    bedLabel.style.opacity = 0.55 + 0.45 * clamp((p - 0.55) / 0.35, 0, 1);
    hint.style.opacity = clamp(1 - p * 6, 0, 1);
  }

  let ticking = false;
  window.addEventListener('scroll', () => {
    if(!ticking){ ticking = true; requestAnimationFrame(() => { ticking = false; update(); }); }
  }, {passive:true});
  // re-measure on resize and whenever the home page is shown again
  if('ResizeObserver' in window) new ResizeObserver(layout).observe(stage);
  else window.addEventListener('resize', layout);
  if(document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
  layout();
})();
'''

s = open(SRC).read()
assert 'vb-section' not in s, 'already embedded'
anchor_css = '</style>'
i = s.index(anchor_css)
s = s[:i] + css + s[i:]
# place the section right after "How it's made"
a = s.index('<section id="process">')
b = s.index('</section>', a) + len('</section>')
s = s[:b] + '\n' + html + s[b:]
# script at the end of the last script block
j = s.rindex('</script>')
s = s[:j] + js + s[j:]
open(SRC, 'w').write(s)
print('embedded; size', len(s))
